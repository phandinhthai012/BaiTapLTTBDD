import { Text, View, StyleSheet, Image,TouchableOpacity,TextInput,FlatList,ScrollView } from 'react-native';
import react,{useState,useEffect} from 'react' //screen
import {NavigationContainer,useNavigation} from '@react-navigation/native' 

export default function Screen02() {
  const navigation = useNavigation()
  const list =['Real Estate','Apartment','House','Motel']
  const list2 =[{id:'1',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/1.png')},{id:'2',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/2.jpg')},{id:'3',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/3.jpg')}]
 const list3 =[{id:'1',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/1.png')},{id:'2',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/2.jpg')},{id:'3',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/3.jpg')},{id:'4',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/5.jpg')},{id:'5',name:'abcasssssss',price:'400000',img:require('./Data_Chieu/5.jpg')},]
  const [data1,setData1] = useState([])
  const [data2,setData2] = useState([])

  const fetchData1 = () => {
    fetch('https://64583ae61a4c152cf9937c0c.mockapi.io/api/v1/type')
      .then((response) => response.json())
      .then((response) => setData1(response))
      .catch((error) => alert('error')); 
  };
  const fetchData2 = async ()=>{
    fetch('https://64583ae61a4c152cf9937c0c.mockapi.io/api/v1/todo')
      .then((response) => response.json())
      .then((response) => setData2(response))
      .catch((error) => alert('error')); 
  }
  
  useEffect(()=>{
    fetchData1()
    fetchData2()
  },[])
  return (
    <ScrollView style={styles.container}>
      <View style={{flexDirection:'row',justifyContent:'space-around',width:'95%',borderRadius:20,borderWidth:1,padding:8}}>
        <Image style={{width:20,height:20}} source={require('./Data_Chieu/home.png')}/>
        <TextInput style={{width:'70%'}} placeholder='Search' placeholderTextColor='gray'/>
        <Image style={{width:20,height:20}} source={require('./Data_Chieu/activity.png')}/>
      </View>
      <View style={{width:300,height:50,marginTop:20}}>
        <FlatList
          data={data1}
          renderItem={({item})=>{
            return( 
              <TouchableOpacity style={{width:80,padding:8,borderWidth:1,borderRadius:50,alignItems:'center',marginHorizontal:10}}>
                <Text>{item.type}</Text>
              </TouchableOpacity>
            )
          }}
          horizontal={true}
        />
      </View>
      <View style={{width:320,height:220,marginTop:20}}>
        <FlatList
          data={data2}
          renderItem={({item})=>{
            return(
              <View style={{marginHorizontal:10}}>
                <Image style={{width:170,height:150}} source={item.img}/>
                <Text style={{fontSize:18}}>$ {item.price}</Text>
                <Text  style={{fontSize:14,color:'gray'}}>{item.name}</Text>
              </View>
            )
          }}
          horizontal={true}
        />
      </View>
      <View style={{width:330,height:150,marginTop:20,alignItems:'center'}}>
        <FlatList
          data={data2}
          renderItem={({item})=>{
            return(
              <View style={{marginHorizontal:10,height:150,position:'relative'}}>
                <Image style={{width:120,height:120}} source={item.img}/>
                <Text style={{color:'black',position:'absolute',top:50,left:20,fontWeight:'bold'}}>{item.name}</Text>
              </View>
            )
          }}
          horizontal={false}
          numColumns={2}
        />
      </View>
      <View style={{width:'100%',height:70,flexDirection:'row',justifyContent:'space-around',alignItems:'center'}}>
         <TouchableOpacity 
             onPress={()=>{
               navigation.navigate('screen03')
             }}
             style={{justifyContent:'center',alignItems:'center'}}>
           <Image style={{width:20,height:20}} source={require('./Data_Chieu/home.png')}/>
           <Text>home</Text>
         </TouchableOpacity>
         <TouchableOpacity style={{justifyContent:'center',alignItems:'center'}}>
           <Image style={{width:20,height:20}} source={require('./Data_Chieu/mail-inbox-app.png')}/>
           <Text>mail</Text>
         </TouchableOpacity>
         <TouchableOpacity style={{justifyContent:'center',alignItems:'center'}}>
           <Image style={{width:20,height:20}} source={require('./Data_Chieu/activity.png')}/>
           <Text>activity</Text>
         </TouchableOpacity>
         <TouchableOpacity style={{justifyContent:'center',alignItems:'center'}}>
           <Image style={{width:20,height:20}} source={require('./Data_Chieu/profile.png')}/>
           <Text>profile</Text>
         </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    alignItems: 'center',
    padding: 0,
  },
});
