import { Text, View, StyleSheet, Image,TouchableOpacity } from 'react-native';
import react,{useState,useEffect} from 'react' //screen
import {NavigationContainer,useNavigation} from '@react-navigation/native' 
export default function Screen01() {
  const navigation = useNavigation()
  return (
    <View style={styles.container}>
      <View style={{width:'100%',position:'relative',height:'50%'}}>
        <Image style={{width:'100%',height:300,position:'absolute'}} source={require('./Data_Chieu/back_ground.jpg')}/>
        <View style={{flexDirection:'row',alignItems:'center',top:0,padding:8,gap:5}}>
          <Image style={{width:25,height:25}} source={require('./Data_Chieu/profile.png')}/>
          <Text style={{color:'black'}}>Nhome</Text>
        </View>
        <Text style={{fontSize:26,fontWeight:'bold',position:'absolute',top:200,color:'white',padding:16,width:'80%'}}>Discover Your Dream Home</Text>
      </View>
      <View style={{flexDirection:'row',gap:5,marginTop:10,width:'90%',justifyContent:'space-between'}}>
        <TouchableOpacity 
            onPress={()=>{
              navigation.navigate('screen02')
            }}
            style={{backgroundColor:"black",padding:10,borderWidth:1,borderRadius:20,width:150,justifyContent:'center',alignItems:'center'}}>
          <Text  style={{color:'white'}}>Login</Text>
        </TouchableOpacity>
         <TouchableOpacity style={{backgroundColor:"white",padding:10,borderWidth:1,borderRadius:20,width:150,justifyContent:'center',alignItems:'center'}}>
          <Text  style={{color:'black'}}>Sign Up</Text>
        </TouchableOpacity>
      </View>
      <Text style={{marginTop:10,marginBottom:10,}}>_______or login with_______</Text>
      <View style={{flexDirection:'column',gap:5,marginTop:10,width:'90%',}}>
          <TouchableOpacity style={{backgroundColor:"white",padding:10,borderWidth:1,borderRadius:20,width:'100%',justifyContent:'center',alignItems:'center',flexDirection:'row',gap:20}}>
          <Image style={{width:25,height:25}} source={require('./Data_Chieu/google.png')}/>
          <Text  style={{color:'black'}}>Continue with google</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{backgroundColor:"white",padding:10,borderWidth:1,borderRadius:20,width:'100%',justifyContent:'center',alignItems:'center',flexDirection:'row',gap:20}}>
          <Image style={{width:25,height:25}} source={require('./Data_Chieu/apple-logo.png')}/>
          <Text  style={{color:'black'}}>Continue with apple</Text>
        </TouchableOpacity>
        <TouchableOpacity style={{backgroundColor:"white",padding:10,borderWidth:1,borderRadius:20,width:'100%',justifyContent:'center',alignItems:'center',flexDirection:'row',gap:20}}>
          <Image style={{width:25,height:25}} source={require('./Data_Chieu/facebook.png')}/>
          <Text  style={{color:'black'}}>Continue with facebook</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    alignItems: 'center',
    padding: 0,
  },
});
