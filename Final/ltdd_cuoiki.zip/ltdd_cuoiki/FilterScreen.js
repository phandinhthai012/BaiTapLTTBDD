import { Text, View, StyleSheet, Image,TouchableOpacity ,FlatList} from 'react-native';
import react,{useState,useEffect} from 'react' //screen
import {NavigationContainer,useNavigation} from '@react-navigation/native' 
export default function Screen01() {
  const navigation = useNavigation()
  const list =['Real Estate','Apartment','House','Motel']
  return (
    <View style={styles.container}>
      <View style={{flexDirection:'row',justifyContent:'space-around',width:'95%',padding:8}}>
        <TouchableOpacity>
           <Image style={{width:20,height:20}} source={require('./Data_Chieu/home.png')}/>
        </TouchableOpacity>
        <Text>Filter Porperty</Text>
        <Image style={{width:20,height:20}} source={require('./Data_Chieu/activity.png')}/>
      </View>
      <View style={{flexDirection:'row',gap:5,marginTop:10,width:'90%',justifyContent:'space-between',backgroundColor:'gray',borderRadius:20,}}>
        <TouchableOpacity 
            // onPress={()=>{
            //   navigation.navigate('screen02')
            // }} 
            style={{backgroundColor:"gray",padding:10,borderWidth:0,borderRadius:20,width:150,justifyContent:'center',alignItems:'center'}}>
          <Text  style={{color:'white'}}>For Rent</Text>
        </TouchableOpacity>
         <TouchableOpacity style={{backgroundColor:"white",padding:10,borderWidth:1,borderRadius:20,width:150,justifyContent:'center',alignItems:'center'}}>
          <Text  style={{color:'black'}}>For Rent</Text>
        </TouchableOpacity>
      </View>
      <View style={{width:'100%',marginTop:10,position:'relative'}}>
        <Text style={{fontWeight:'bold',marginLeft:20}}>Price range</Text>
        <Image style={{width:'90%',height:120,alignSelf:'center'}} source={require('./Data_Chieu/price_range.PNG')}/>
      </View>
      <View style={{width:'100%',height:90,marginTop:20}}>
      <Text style={{fontWeight:'bold',marginLeft:20,marginBottom:20}}>House type</Text>
        <FlatList
          data={list}
          renderItem={({item})=>{
            return( 
              <TouchableOpacity style={{width:80,padding:8,borderWidth:1,borderRadius:50,alignItems:'center',marginHorizontal:10}}>
                <Text style={{width:70}}>{item}</Text>
              </TouchableOpacity>
            )
          }}
          horizontal={true}
        />
        </View>
        <View style={{width:'100%',marginTop:20,padding:8, flexDirection:'row',justifyContent:'space-between'}}>
          <View>
           <Text style={{fontSize:18,fontWeight:'bold',marginBottom:10}}>Rooms</Text>
           <View style={{flexDirection:'row',gap:10}}>
            <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>1</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>2</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>3</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>4+</Text>
            </View>
          </View>
          <View>
           <Text style={{fontSize:18,fontWeight:'bold',marginBottom:10}}>bathRooms</Text>
           <View style={{flexDirection:'row',gap:10}}>
            <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>1</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>2</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>3</Text>
             <Text style={{padding:2,borderRadius:'50%',borderWidth:1,width:25,textAlign:'center'}}>4+</Text>
            </View>
          </View>
        </View>
        <View style={{width:'100%',marginTop:20,padding:8, flexDirection:'row'}}>
           <View style={{flexDirection:'row',gap:10}}>
            <Text style={{fontSize:18,fontWeight:'bold',marginBottom:10}}>Ammenties</Text>
          </View>
        
        </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex:1,
    alignItems: 'center',
    padding: 0,
  },
});
