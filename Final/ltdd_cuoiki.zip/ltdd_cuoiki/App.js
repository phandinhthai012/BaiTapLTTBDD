import { Text, SafeAreaView, StyleSheet } from 'react-native';

import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Screen01 from './screen01';
import Screen02 from './showScreen';
import Screen03 from './FilterScreen';
const Stack = createStackNavigator();
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="screen01">
        <Stack.Screen name="screen01" component={Screen01} options={{headerShown:false}} />
        <Stack.Screen name="screen02" component={Screen02} options={{headerShown:false}} />
        <Stack.Screen name="screen03" component={Screen03} options={{headerShown:false}} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({

});
